# Zino Pack

Modpack made for fun, that we use to play with friends.

## Description

Over 48 mods, including:

### Cosmetic mods

- [More Company](https://thunderstore.io/c/lethal-company/p/notnotnotswipez/MoreCompany/)
- [More Suits](https://thunderstore.io/c/lethal-company/p/x753/More_Suits/)
- [More Emotes](https://thunderstore.io/c/lethal-company/p/Sligili/More_Emotes/)
- [Simple hats](https://thunderstore.io/c/lethal-company/p/fonnymunkey/SimpleHats/)

### Fun mods

- [SkinWalker](https://thunderstore.io/c/lethal-company/p/RugbugRedfern/Skinwalkers/)
- [JesterFree](https://thunderstore.io/c/lethal-company/p/AriDev/JesterFree/)
- [Mimics](https://thunderstore.io/c/lethal-company/p/x753/Mimics/)
- [YipeeMod](hhttps://thunderstore.io/c/lethal-company/p/sunnobunno/YippeeMod/)

And many more!
